<?php
include "db_connect.php"; 

//Get the parents info
$ParentResult = $conn->query("SELECT ParentsID, FirstName FROM parents ORDER BY ParentsID");
$all_parents = $ParentResult->fetch_all(MYSQLI_ASSOC);

//adding a new parent
if (isset($_POST["addParent"])) {
    $id = $_POST["ParentsID"];
    $first = $_POST["FirstName"];
    $last = $_POST["LastName"];
    $phone = $_POST["PhoneNumber"];
    $email = $_POST["Email"];
    $address = $_POST["Address"];

    $insert = "INSERT INTO parents (ParentsID, FirstName, LastName, PhoneNumber, Email, Address)
               VALUES ('$id', '$first', '$last', '$phone', '$email', '$address')";

    $msg = $conn->query($insert) ? "Parent added successfully!" : "Error: " . $conn->error;
}

//deleting parent
if (isset($_POST["deleteParent"])) {
    $delID = $_POST["DeleteParentID"];
    $stmt = $conn->prepare("DELETE FROM parents WHERE ParentsID = ?");
    $stmt->bind_param("i", $delID);
    $msg = $stmt->execute() ? "Parent deleted successfully!" : "Error deleting parent: " . $stmt->error;
    $stmt->close();
}

// updating parent
if (isset($_POST["updateParent"])) {
    $id = $_POST["uParentsID"];
    $first = $_POST["uFirstName"];
    $last = $_POST["uLastName"];
    $phone = $_POST["uPhoneNumber"];
    $email = $_POST["uEmail"];
    $address = $_POST["uAddress"];

    $update = "UPDATE parents SET 
               FirstName='$first', LastName='$last', PhoneNumber='$phone',
               Email='$email', Address='$address' WHERE ParentsID=$id";

    $msg = $conn->query($update) ? "Parent updated successfully!" : "Error updating parent: " . $conn->error;
}
?>

<html>
<head>
<meta charset="utf-8">
<title>Parents - St Alphonsus Primary School</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style> /* Style for Page & Table Layout */
.page-header { 
    background:#4CAF50; 
    color:white; 
    padding:40px 20px; 
    text-align:center; 
    position:sticky; 
    top:0; z-index:10; 
}
label { 
    font-weight:bold; 
    display:block; 
    margin-top:10px; 
}
select, input[type="text"], input[type="email"] { 
    padding:6px; 
    margin-bottom:10px; 
    width:250px; 
    border-radius:5px; 
    border:1px solid #ccc; 
}
input[type="submit"] { 
    padding:8px 15px; 
    background:#4CAF50; 
    color:white; 
    border:none; 
    border-radius:5px; 
    cursor:pointer; 
}
input[type="submit"]:hover { 
    background:#45a049; 
}
.table-responsive { 
    width:95%; 
    margin:20px auto; 
    overflow-x:auto; 
}
table { 
    width:100%; 
    border-collapse:collapse; 
    border:2px solid #4CAF50; 
    font-family:Arial,sans-serif; 
}
thead th { 
    background:#4CAF50; 
    color:white; 
    padding:10px; 
}
tbody td { 
    border:1px solid #ddd; 
    padding:8px; 
}
tbody tr:nth-child(even) { 
    background:#f2f2f2; 
}
</style>
</head>

<body>

<!--Page Header-->
<div class="page-header">
    <h1>St Alphonsus Primary School</h1>
    <h4>Attendance</h4>
</div>

<!--Sidebar-->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:25%">
<h3 class="w3-bar-item w3-green">School Portal</h3>
<a href="Admin.php" class="w3-bar-item w3-button">Admin</a>
<a href="Admin_Attendance.php" class="w3-bar-item w3-button">Attendance</a>
<a href="Admin_Classes.php" class="w3-bar-item w3-button">Classes</a>
<a href="Admin_Parents.php" class="w3-bar-item w3-button w3-green">Parent</a>
<a href="Admin_Parent&Pupil.php" class="w3-bar-item w3-button">Parents & Pupil</a>
<a href="Admin_Points.php" class="w3-bar-item w3-button">Points</a>
<a href="Admin_Students.php" class="w3-bar-item w3-button">Student</a>
<a href="Admin_Teacher.php" class="w3-bar-item w3-button ">Teacher</a>
<a href="Admin_TeacherAssistant.php" class="w3-bar-item w3-button">Teacher Assistant</a>
<h7><a href="index.php" class="w3-bar-item w3-button w3-green">Log Out</a></h7>
</div>

<div style="margin-left:25%; padding:20px;">
<?php if (!empty($msg)) echo "<p style='color:green;font-weight:bold;'>$msg</p>"; ?>

<!-- look at the parent -->
<h2>View Parent</h2>
<form method="POST">
    <label>Select Parent:</label>
    <select name="Parent" onchange="this.form.submit()">
        <option value="">-- Select a Parent --</option>
        <?php foreach ($all_parents as $p): ?>
            <option value="<?= $p['ParentsID'] ?>"><?= $p['ParentsID'] ?> - <?= $p['FirstName'] ?></option>
        <?php endforeach; ?>
    </select>
</form>

<!-- Show Parents Info -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["Parent"])) {
    $parentID = $_POST["Parent"];
    $query = "SELECT * FROM parents WHERE ParentsID = $parentID";
    $res = $conn->query($query);
    $row = $res->fetch_assoc();
    if ($row) {
        echo "<div class='table-responsive'>
                <table>
                    <thead>
                        <tr>
                            <th>ParentsID</th>
                            <th>FirstName</th>
                            <th>LastName</th>
                            <th>PhoneNumber</th>
                            <th>Email</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{$row['ParentsID']}</td>
                            <td>{$row['FirstName']}</td>
                            <td>{$row['LastName']}</td>
                            <td>{$row['PhoneNumber']}</td>
                            <td>{$row['Email']}</td>
                            <td>{$row['Address']}</td>
                        </tr>
                    </tbody>
                </table>
              </div>";
    }
}
?>

<!-- adding parent -->
<h2>Add Parent</h2>
<form method="POST">
    <label>ParentsID:</label>
    <input type="text" name="ParentsID" required>
    <label>FirstName:</label>
    <input type="text" name="FirstName" required>
    <label>LastName:</label>
    <input type="text" name="LastName" required>
    <label>PhoneNumber:</label>
    <input type="text" name="PhoneNumber" required>
    <label>Email:</label>
    <input type="email" name="Email" required>
    <label>Address:</label>
    <input type="text" name="Address" required>
    <br><br>
    <input type="submit" name="addParent" value="Add Parent">
</form>

<!-- deleting parent -->
<h2>Delete Parent</h2>
<form method="POST">
    <label>ParentID to Delete:</label>
    <input type="text" name="DeleteParentID" required>
    <input type="submit" name="deleteParent" value="Delete">
</form>

<!-- updating parent infoT -->
<h2>Update Parent</h2>
<form method="POST">
    <label>Select ParentID to Update:</label>
    <select name="uParentsID" required>
        <?php foreach ($all_parents as $p): ?>
            <option value="<?= $p['ParentsID'] ?>"><?= $p['ParentsID'] ?> - <?= $p['FirstName'] ?></option>
        <?php endforeach; ?>
    </select>
    <label>FirstName:</label>
    <input type="text" name="uFirstName">
    <label>LastName:</label>
    <input type="text" name="uLastName">
    <label>PhoneNumber:</label>
    <input type="text" name="uPhoneNumber">
    <label>Email:</label>
    <input type="text" name="uEmail">
    <label>Address:</label>
    <input type="text" name="uAddress">
    <br><br>
    <input type="submit" name="updateParent" value="Update Parent">
</form>

</div>
</body>
</html>

<?php $conn->close(); ?>
