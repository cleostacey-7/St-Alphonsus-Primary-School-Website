<?php
include "db_connect.php";

//Get the attendance
$AttendanceResult = $conn->query("SELECT AttendanceID, PupilsID, OverallAttendance FROM attendance ORDER BY AttendanceID");
$all_attendance = $AttendanceResult->fetch_all(MYSQLI_ASSOC);

//adding new attendance
if (isset($_POST["addAttendance"])) {
    $attendanceID = $_POST["AttendanceID"];
    $present = $_POST["Present"];
    $absent = $_POST["Absent"];
    $lateness = $_POST["Lateness"];
    $pupilID = $_POST["PupilsID"];
    $overall = $_POST["OverallAttendance"];

    $insert = "INSERT INTO attendance (AttendanceID, Present, Absent, Lateness, PupilsID, OverallAttendance)
               VALUES ('$attendanceID', '$present', '$absent', '$lateness', '$pupilID', '$overall')";

    if ($conn->query($insert)) {
        $msg = "Attendance added successfully!";
    } else {
        $msg = "Error: " . $conn->error;
    }
}

// deleting attendance
if (isset($_POST["deleteAttendance"])) {
    $delID = $_POST["DeleteAttendanceID"];
    $stmt = $conn->prepare("DELETE FROM attendance WHERE AttendanceID = ?");
    $stmt->bind_param("i", $delID);
    if ($stmt->execute()) {
        $msg = "Attendance deleted successfully!";
    } else {
        $msg = "Error deleting attendance: " . $stmt->error;
    }
    $stmt->close();
}

// update attendance
if (isset($_POST["updateAttendance"])) {
    $aid = $_POST["uAttendanceID"];
    $present = $_POST["uPresent"];
    $absent = $_POST["uAbsent"];
    $lateness = $_POST["uLateness"];
    $pupilID = $_POST["uPupilsID"];
    $overall = $_POST["uOverallAttendance"];

    $update = "UPDATE attendance SET 
               Present='$present', Absent='$absent', Lateness='$lateness', 
               PupilsID='$pupilID', OverallAttendance='$overall'
               WHERE AttendanceID=$aid";

    if ($conn->query($update)) {
        $msg = "Attendance updated successfully!";
    } else {
        $msg = "Error updating attendance: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Attendance - St Alphonsus Primary School</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style> /* Style for Page & Table Layout */
.page-header {
    background-color: #4CAF50;
    color: white;
    padding: 40px 20px;
    text-align: center;
    position: sticky;
    top: 0;
    z-index: 10;
}

label { 
    font-weight: bold; 
    display: block; 
    margin-top: 10px; 
}

select, input[type="text"] {
     padding: 6px; 
     margin-bottom: 10px; 
     width: 250px; 
     border-radius:5px; 
     border:1px solid #ccc; 
}

input[type="submit"] { 
    padding:8px 15px; 
    background:#4CAF50; 
    color:white; 
    border:none; 
    border-radius:5px; 
    cursor:pointer; 
}

input[type="submit"]:hover { 
    background:#45a049; 
}

.table-responsive { 
    width:95%; 
    margin:20px auto; 
    overflow-x:auto; 
}

table { 
    width:100%; 
    border-collapse: collapse; 
    border:2px solid #4CAF50; 
    font-family: Arial,sans-serif; 
}

thead th { 
    background:#4CAF50; 
    color:white; 
    padding:10px; 
}

tbody td { 
    border:1px solid #ddd; 
    padding:8px; 
}

tbody tr:nth-child(even) { 
    background:#f2f2f2; 
}

</style>
</head>
<body>
<!--Page Header-->
<div class="page-header">
    <h1>St Alphonsus Primary School</h1>
    <h4>Attendance</h4>
</div>

<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:25%">
  <br>
  <h3 class="w3-bar-item w3-green">School Portal</h3>
  <a href="Admin.php" class="w3-bar-item w3-button">Admin</a>
  <a href="Admin_Attendance.php" class="w3-bar-item w3-button w3-green">Attendance</a>
  <a href="Admin_Classes.php" class="w3-bar-item w3-button">Classes</a>
  <a href="Admin_Parents.php" class="w3-bar-item w3-button">Parent</a>
  <a href="Admin_Parent&Pupil.php" class="w3-bar-item w3-button">Parents & Pupil</a>
  <a href="Admin_Points.php" class="w3-bar-item w3-button">Points</a>
  <a href="Admin_Students.php" class="w3-bar-item w3-button">Student</a>
  <a href="Admin_Teacher.php" class="w3-bar-item w3-button">Teacher</a>
  <a href="Admin_TeacherAssistant.php" class="w3-bar-item w3-button">Teacher Assistant</a>
  <h7><a href="index.php" class="w3-bar-item w3-button w3-green">Log Out</a></h7>
</div>

<div style="margin-left:25%;padding:20px;">

<?php if (!empty($msg)) echo "<p style='color:green;font-weight:bold;'>$msg</p>"; ?>

<!-- Choosing Attendance -->
<h2>View Attendance</h2>
<form method="POST">
    <label>Select Attendance:</label>
    <select name="AttendanceID" onchange="this.form.submit()">
        <option value="">-- Select Attendance --</option>
        <?php foreach ($all_attendance as $att): ?>
            <option value="<?= $att['AttendanceID'] ?>">
                ID <?= $att['AttendanceID'] ?> - Pupil <?= $att['PupilsID'] ?> (<?= $att['OverallAttendance'] ?>%)
            </option>
        <?php endforeach; ?>
    </select>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["AttendanceID"])) {
    $attendanceID = $_POST["AttendanceID"];
    $query = "SELECT * FROM attendance WHERE AttendanceID = $attendanceID";
    $res = $conn->query($query);
    $row = $res->fetch_assoc();

    // Showing the attendance info in a table 
    if ($row) {
        echo "<div class='table-responsive'>
                <table>
                    <thead>
                        <tr>
                            <th>AttendanceID</th>
                            <th>Present</th>
                            <th>Absent</th>
                            <th>Lateness</th>
                            <th>PupilID</th>
                            <th>OverallAttendance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{$row['AttendanceID']}</td>
                            <td>{$row['Present']}</td>
                            <td>{$row['Absent']}</td>
                            <td>{$row['Lateness']}</td>
                            <td>{$row['PupilsID']}</td>
                            <td>{$row['OverallAttendance']}%</td>
                        </tr>
                    </tbody>
                </table>
              </div>";
    }
}
?>

<!-- adding attendance -->
<h2>Add Attendance</h2>
<form method="POST">
    <label>AttendanceID:</label>
    <input type="text" name="AttendanceID" required>
    <label>Present:</label>
    <input type="text" name="Present" required>
    <label>Absent:</label>
    <input type="text" name="Absent" required>
    <label>Lateness:</label>
    <input type="text" name="Lateness" required>
    <label>PupilID:</label>
    <input type="text" name="PupilsID" required>
    <label>OverallAttendance:</label>
    <input type="text" name="OverallAttendance" required>
    <br><br>
    <input type="submit" name="addAttendance" value="Add Attendance">
</form>

<!-- deleting attendance -->
<h2>Delete Attendance</h2>
<form method="POST">
    <label>AttendanceID to Delete:</label>
    <input type="text" name="DeleteAttendanceID" required>
    <input type="submit" name="deleteAttendance" value="Delete">
</form>

<!-- updating attendance -->
<h2>Update Attendance</h2>
<form method="POST">
    <label>Select AttendanceID to Update:</label>
    <select name="uAttendanceID" required>
        <?php foreach ($all_attendance as $att): ?>
            <option value="<?= $att['AttendanceID'] ?>">
                <?= $att['AttendanceID'] ?> - Pupil <?= $att['PupilsID'] ?>
            </option>
        <?php endforeach; ?>
    </select>
    <label>Present:</label>
    <input type="text" name="Present">
    <label>Absent:</label>
    <input type="text" name="Absent">
    <label>Lateness:</label>
    <input type="text" name="Lateness">
    <label>PupilID:</label>
    <input type="text" name="PupilsID">
    <label>OverallAttendance:</label>
    <input type="text" name="OverallAttendance">
    <br><br>
    <input type="submit" name="updateAttendance" value="Update Attendance">
</form>

</div>
</body>
</html>

<?php $conn->close(); ?>
